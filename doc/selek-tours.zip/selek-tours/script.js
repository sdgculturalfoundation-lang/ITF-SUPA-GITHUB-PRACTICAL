var mem={};
function sget(k){try{return localStorage.getItem(k)}catch(e){return mem[k]||null}}
function sset(k,v){try{localStorage.setItem(k,v)}catch(e){mem[k]=v}}
function sdel(k){try{localStorage.removeItem(k)}catch(e){delete mem[k]}}
function users(){try{return JSON.parse(sget('selek_users')||'{}')}catch(e){return{}}}
async function hash(s){try{var b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('selek:'+s));return Array.from(new Uint8Array(b)).map(function(x){return x.toString(16).padStart(2,'0')}).join('')}catch(e){return 'p:'+s}}
var $=function(i){return document.getElementById(i)},mode='in';
function render(){var u=sget('selek_session');$('guest').style.display=u?'none':'inline';$('userbox').style.display=u?'flex':'none';if(u){try{$('hello').textContent='Hi, '+(JSON.parse(u).name||'friend')}catch(e){}}}
function setMode(m){mode=m;var up=m==='up';$('dTitle').textContent=up?'Create account':'Sign in';$('go').textContent=up?'Create account':'Sign in';$('nameRow').style.display=up?'block':'none';$('swText').textContent=up?'Already registered?':'No account yet?';$('swBtn').textContent=up?'Sign in':'Create one';$('pw').autocomplete=up?'new-password':'current-password';$('msg').textContent=''}
$('siBtn').onclick=function(){setMode('in');$('dlg').showModal()};
$('cancel').onclick=function(){$('dlg').close()};
$('swBtn').onclick=function(){setMode(mode==='in'?'up':'in')};
$('soBtn').onclick=function(){sdel('selek_session');render()};
$('go').onclick=async function(){
 var m=$('msg');m.className='msg';var em=$('em').value.trim().toLowerCase(),pw=$('pw').value,nm=$('fn').value.trim();
 if(!/^\S+@\S+\.\S+$/.test(em)){m.textContent='Enter a valid email address.';return}
 if(pw.length<6){m.textContent='Use a password of at least 6 characters.';return}
 var all=users(),h=await hash(pw);
 if(mode==='up'){
  if(!nm){m.textContent='Enter your full name.';return}
  if(all[em]){m.textContent='That email is already registered. Sign in instead.';return}
  all[em]={name:nm,h:h};sset('selek_users',JSON.stringify(all));
 }else{
  if(!all[em]||all[em].h!==h){m.textContent='Email or password is incorrect.';return}
 }
 sset('selek_session',JSON.stringify({email:em,name:all[em].name}));
 $('em').value=$('pw').value=$('fn').value='';$('dlg').close();render();
};
render();
