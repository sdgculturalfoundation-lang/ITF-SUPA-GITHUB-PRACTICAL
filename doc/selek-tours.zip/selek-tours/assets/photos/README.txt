Put your own tour photos in this folder (jpg, webp or png).
Then replace each "[Add photo: ...]" box in index.html with an <img src="assets/photos/your-photo.jpg" alt="Describe the photo"> tag.
