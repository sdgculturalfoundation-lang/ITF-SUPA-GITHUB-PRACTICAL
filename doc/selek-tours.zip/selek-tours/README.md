# Selek Tour Operation Firm website

Selek, Tour Operation Firm, Jos, Plateau State, Nigeria
CEO: Selek Domshak Amos | Phone/WhatsApp: 07035681377

## Files
- index.html : the page content
- style.css : green theme, light and dark mode
- script.js : sign in, create account and sign out
- assets/photos/ : put your own photos here

## Open it
Double-click index.html. No installation needed.

## Put it online
Upload the whole folder to any static host (Netlify Drop, GitHub Pages, Vercel, or your web hosting file manager).

## Replace with your real details
- Guest reviews and names (Reviews section)
- Photos (Photo gallery section)
- Prices, tour dates and your terms and conditions
- Add an email address in the Contact section if you have one

## Sign in and sign out
This is a front-end demo. Accounts are saved only in the visitor's own browser, so they do not work across devices. For real accounts, connect a backend such as Firebase Authentication or Supabase.
