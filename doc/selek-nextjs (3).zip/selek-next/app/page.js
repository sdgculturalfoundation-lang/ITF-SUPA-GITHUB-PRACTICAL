import Header from "@/components/Header";
import { SITE, why, destinations, packages, festivals, commitments, faq } from "@/lib/data";

const Cards = ({ items, cls = "" }) => (
  <div className="grid">{items.map(([t, p]) => (<div key={t} className={`card ${cls}`}><h3>{t}</h3><p>{p}</p></div>))}</div>
);
const Tagged = ({ items }) => (
  <div className="grid">{items.map(([tag, t, p]) => (<div key={t} className="card"><span className="tag">{tag}</span><h3>{t}</h3><p>{p}</p></div>))}</div>
);

export default function Home() {
  return (
    <>
      <div className="top"><div className="wrap">
        <span>{SITE.place}</span><a href={`tel:${SITE.tel}`}>Call {SITE.phoneDisplay}</a>
      </div></div>
      <Header />
      <main id="top">
        <div className="hero"><div className="wrap">
          <h1>Explore the Plateau with Selek</h1>
          <p>Selek is a tour operation firm based in Jos, Plateau State, Nigeria. We plan custom trips, group tours and family holidays across the Plateau’s rocks, waterfalls, wildlife parks and cool highland towns.</p>
          <p><a className="btn" href="#contact">Let’s start planning</a> <a className="btn ghost" href="#packages">View tour packages</a></p>
        </div>
          <svg viewBox="0 0 1200 130" preserveAspectRatio="none" aria-hidden="true"><path d="M0 130V80c60-30 110-34 170-10 50 20 80 22 130-14 40-28 90-30 130-6 50 30 90 28 140-8 50-34 100-30 150 0 40 24 90 26 140-4 60-38 110-30 170 6 40 22 80 18 120-4V130z" fill="var(--bg)" /></svg>
        </div>

        <section id="about"><div className="wrap">
          <h2>A local tour operator for Jos and the Plateau</h2>
          <p className="lead">We are a locally run firm. We know the roads, the seasons and the communities, so your trip is planned around where you want to go, how long you have and how you like to travel.</p>
          <Cards items={why} />
          <div className="card ceo" style={{ marginTop: 28 }}>
            <div className="avatar" aria-hidden="true">SA</div>
            <div><h3 style={{ margin: 0 }}>{SITE.ceo}</h3>
              <p>Chief Executive Officer, Selek. Reach him directly on <a href={`tel:${SITE.tel}`}><strong>{SITE.phoneDisplay}</strong></a>.</p></div>
          </div>
        </div></section>

        <section className="alt" id="destinations"><div className="wrap">
          <h2>Popular destinations on the Plateau</h2>
          <Cards items={destinations} cls="dest" />
        </div></section>

        <section id="packages"><div className="wrap">
          <h2>Our tour packages</h2>
          <p className="lead">These are starting points. Every package can be shortened, extended or rebuilt around your group.</p>
          <Tagged items={packages} />
          <p style={{ marginTop: 26 }}><a className="btn" href={SITE.wa}>Design your tour on WhatsApp</a></p>
        </div></section>

        <section className="alt" id="gallery"><div className="wrap">
          <h2>Photo gallery</h2>
          <p className="lead">Add your own tour photos here (put files in public/photos).</p>
          <div className="grid">{["Jos city", "rocks and hills", "waterfall", "your guests"].map((x) => <div key={x} className="ph">[Add photo: {x}]</div>)}</div>
        </div></section>

        <section id="festivals"><div className="wrap">
          <h2>Festival and seasonal tours</h2>
          <p className="lead">Travel with family and friends during the holidays. Dates and details are confirmed when you enquire.</p>
          <Tagged items={festivals} />
        </div></section>

        <section className="alt" id="reviews"><div className="wrap">
          <h2>What our guests say</h2>
          <div className="grid">{[1, 2, 3].map((n) => (
            <div key={n} className="card quote"><p>[Add a real guest review here]</p><strong>[Guest name]</strong></div>))}</div>
          <p style={{ marginTop: 26 }}><a className="btn" href={SITE.waReview}>Write a review</a></p>
        </div></section>

        <section id="commitments"><div className="wrap">
          <h2>Our commitments</h2>
          <Cards items={commitments} />
        </div></section>

        <section className="alt" id="faq"><div className="wrap">
          <h2>Frequently asked questions</h2>
          {faq.map(([q, a]) => (<details key={q}><summary>{q}</summary><p>{a}</p></details>))}
        </div></section>

        <section className="contact" id="contact"><div className="wrap">
          <h2>Contact Selek</h2>
          <p><strong>{SITE.ceo}</strong>, CEO<br />Selek, Tour Operation Firm<br />{SITE.place}</p>
          <p>Phone and WhatsApp: <a href={`tel:${SITE.tel}`}><strong>{SITE.phoneRaw}</strong></a></p>
          <p><a className="btn" href={`tel:${SITE.tel}`}>Call now</a> <a className="btn" href={SITE.wa}>Message on WhatsApp</a></p>
        </div></section>
      </main>
      <footer><div className="wrap">© 2026 Selek. Tour Operation Firm, Jos, Plateau State, Nigeria. CEO: Selek Domshak Amos.</div></footer>
      <a className="wa" href={SITE.wa}>Chat with us</a>
    </>
  );
}
