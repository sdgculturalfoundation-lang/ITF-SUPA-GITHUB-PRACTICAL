import "./globals.css";
import AuthProvider from "@/components/AuthProvider";

export const metadata = {
  title: "Selek | Tour Operation Firm, Jos, Plateau State, Nigeria",
  description: "Selek is a tour operation firm in Jos, Plateau State, Nigeria. Custom tours, group trips and family holidays across the Plateau.",
};
export const viewport = { width: "device-width", initialScale: 1, viewportFit: "cover" };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;700;800&family=Source+Sans+3:wght@400;600&display=swap" rel="stylesheet" />
      </head>
      <body><AuthProvider>{children}</AuthProvider></body>
    </html>
  );
}
