# Selek Tour Operation Firm (Next.js)

Selek, Tour Operation Firm, Jos, Plateau State, Nigeria
CEO: Selek Domshak Amos | Phone/WhatsApp: 07035681377

## Run it
1. Install Node.js 18.17 or newer.
2. In this folder run: `npm install`
3. Development: `npm run dev` then open http://localhost:3000
4. Production: `npm run build` then `npm start`

## Deploy
Push to GitHub and import the repo in Vercel (free), or run `npm run build && npm start` on any Node host.

## Edit your content
- `lib/data.js`: all text, phone number, WhatsApp links, packages, FAQ, commitments
- `app/page.js`: page layout and sections
- `app/globals.css`: green theme, light and dark mode (change the --g9, --g7, --g5 colours)
- `public/photos/`: your photos

## Replace with real details
Guest reviews, photos, prices, dates, terms and conditions, and an email address.

## Sign in and sign out
`components/AuthProvider.js` is a browser-only demo: accounts and SHA-256 hashed passwords are stored in each visitor's own browser, so they do not work across devices. To get real accounts, replace `signUp`, `signIn` and `signOut` with Firebase Authentication, Supabase Auth or NextAuth.
