Put your own tour photos here, then use <img src="/photos/your-photo.jpg" alt="..."> in app/page.js.
