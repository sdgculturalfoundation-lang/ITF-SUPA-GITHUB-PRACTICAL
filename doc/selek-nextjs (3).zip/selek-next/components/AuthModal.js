"use client";
import { useEffect, useRef, useState } from "react";
import { useAuth } from "./AuthProvider";

export default function AuthModal({ open, onClose }) {
  const { signIn, signUp } = useAuth();
  const ref = useRef(null);
  const [mode, setMode] = useState("in");
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [msg, setMsg] = useState("");
  const up = mode === "up";

  useEffect(() => {
    const d = ref.current; if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  async function submit(e) {
    e.preventDefault();
    const email = f.email.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) return setMsg("Enter a valid email address.");
    if (f.password.length < 6) return setMsg("Use a password of at least 6 characters.");
    if (up && !f.name.trim()) return setMsg("Enter your full name.");
    const err = up ? await signUp(f.name.trim(), email, f.password) : await signIn(email, f.password);
    if (err) return setMsg(err);
    setF({ name: "", email: "", password: "" }); setMsg(""); onClose();
  }
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  return (
    <dialog ref={ref} onClose={onClose}>
      <form onSubmit={submit} noValidate>
        <h3>{up ? "Create account" : "Sign in"}</h3>
        {up && (<><label htmlFor="fn">Full name</label><input id="fn" autoComplete="name" value={f.name} onChange={set("name")} /></>)}
        <label htmlFor="em">Email</label>
        <input id="em" type="email" autoComplete="email" value={f.email} onChange={set("email")} />
        <label htmlFor="pw">Password</label>
        <input id="pw" type="password" autoComplete={up ? "new-password" : "current-password"} value={f.password} onChange={set("password")} />
        <p className="msg" role="alert">{msg}</p>
        <p style={{ display: "flex", gap: 10, alignItems: "center", margin: "10px 0 0" }}>
          <button className="btn" type="submit">{up ? "Create account" : "Sign in"}</button>
          <button className="btn ghost" type="button" onClick={onClose}>Cancel</button>
        </p>
        <p style={{ fontSize: 14, margin: "14px 0 0" }}>
          {up ? "Already registered?" : "No account yet?"}{" "}
          <button className="sw" type="button" onClick={() => { setMode(up ? "in" : "up"); setMsg(""); }}>{up ? "Sign in" : "Create one"}</button>
        </p>
      </form>
    </dialog>
  );
}
