"use client";
import { createContext, useContext, useEffect, useState } from "react";

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

async function hash(s) {
  try {
    const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("selek:" + s));
    return Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, "0")).join("");
  } catch { return "p:" + s; }
}
const read = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

// DEMO AUTH: accounts live only in this browser. Replace these three functions with
// Firebase Auth, Supabase or NextAuth for real accounts across devices.
export default function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  useEffect(() => { setUser(read("selek_session", null)); setReady(true); }, []);

  async function signUp(name, email, password) {
    const users = read("selek_users", {});
    if (users[email]) return "That email is already registered. Sign in instead.";
    users[email] = { name, h: await hash(password) };
    write("selek_users", users);
    const s = { name, email }; write("selek_session", s); setUser(s); return null;
  }
  async function signIn(email, password) {
    const u = read("selek_users", {})[email];
    if (!u || u.h !== (await hash(password))) return "Email or password is incorrect.";
    const s = { name: u.name, email }; write("selek_session", s); setUser(s); return null;
  }
  function signOut() { try { localStorage.removeItem("selek_session"); } catch {} setUser(null); }

  return <Ctx.Provider value={{ user, ready, signUp, signIn, signOut }}>{children}</Ctx.Provider>;
}
