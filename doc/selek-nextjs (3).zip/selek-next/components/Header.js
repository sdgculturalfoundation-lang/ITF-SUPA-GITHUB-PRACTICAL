"use client";
import { useState } from "react";
import { useAuth } from "./AuthProvider";
import AuthModal from "./AuthModal";
import { nav } from "@/lib/data";

export default function Header() {
  const { user, ready, signOut } = useAuth();
  const [menu, setMenu] = useState(false);
  const [modal, setModal] = useState(false);
  return (
    <>
      <header className="nav"><div className="wrap">
        <a className="logo" href="#top">Selek</a>
        <button className="menu" aria-label="Menu" aria-expanded={menu} onClick={() => setMenu(!menu)}>☰</button>
        <nav className={menu ? "open" : ""} onClick={() => setMenu(false)}>
          {nav.map(([h, t]) => <a key={h} href={h}>{t}</a>)}
          {ready && (user ? (
            <span style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span>Hi, {user.name}</span>
              <button className="btn ghost" onClick={signOut}>Sign out</button>
            </span>
          ) : (
            <button className="btn ghost" onClick={() => setModal(true)}>Sign in</button>
          ))}
        </nav>
      </div></header>
      <AuthModal open={modal} onClose={() => setModal(false)} />
    </>
  );
}
