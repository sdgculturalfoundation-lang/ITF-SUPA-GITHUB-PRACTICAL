Upload the FILES in this folder (not the folder itself) so index.html sits at the root.
Required at root: index.html, style.css. Framework preset on Vercel: "Other". Build command: none. Output directory: leave empty.
